<?php
?>
<main class="p-0 m-0">
        <div class="col-md-12 m-0">
            <div class="row pt-5 mx-0 px-0">
                <p class="text-end mt-2 pt-5 position-fixed mx-0 px-0" style="z-index:101;"><a class="bg-dark text-white py-2 px-3 rounded-start" style="text-decoration:none;" href="http://192.168.0.100/kallasa.com.br" >Retornar</a><p>
            </div>
        </div>

        <div class="container-fluid m-0 p-0" style="height: 600px;">
            <div class="row h-100">
                <div class="col-lg-12 ">
                    <div class="container-lg">
                        <table class="table table-striped align-middle h-50 wordkflow-tbl">
                            <input type="hidden" name="timeLine" value="show">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Descrição</th>
                                <th scope="col">Motivo</th>
                                <th scope="col">Data</th>
                            </tr>

                            <tr>
                                <td>1</td>
                                <td>Adição de seções pendentes</td>
                                <td>Atualização</td>
                                <td>31/10/2022</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Divisão do layout em php</td>
                                <td>Atualização</td>
                                <td>12/11/2022</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Possibilidade de adição de casos para datas comemorativas</td>
                                <td>Testes</td>
                                <td>15/11/2022</td>
                            </tr>
                        </table>
                        <?php 
                            //include ('../workflow/curso01.php');
                            //include ('../workflow/curso02.php');
                            //include ('../workflow/curso003.php');
                            //include ('../workflow/curso004.php');
                            include ('../workflow/curso005.php');
                            include ('../workflow/curso006.php');
                        
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </main>