<!DOCTYPE html>
<html lang="pt-br">

    <table border="1px" style="border-color: black; border-radius:5px; padding-top:5px; padding-bottom: 5px; padding-left: 5px; padding-right: 5px;">
        <thead>
            <tr style="background-color:#5d50f7; color:white;">
                <th scope="col">Nome</th>
                <th scope="col">E-mail</th>
                <th scope="col">Data</th>
                <th scope="col">Hora</th>
            </tr>
        </thead>
        <tbody>
            <tr style="background-color: #c0c0c0;">
                <td style="padding-left: 20px; padding-right:20px;">Mark</td>
                <td style="padding-left: 20px; padding-right:20px;">Mark@teste.com</td>
                <td style="padding-left: 20px; padding-right:20px;">01/01/2022</td>
                <td style="padding-left: 20px; padding-right:20px;">20:00</td>
            </tr>
        </tbody>
    </table>

</html>